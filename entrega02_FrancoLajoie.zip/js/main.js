//VARIABLES
const marcas = ["Nike", "Adidas", "Puma", "Reebok", "Converse"]
let carrito = []
let marcaElegida = []

const eleccionNike = [
    { modelo: "Air Max 90", precio: 120 },
    { modelo: "Air Force 1", precio: 110 },
    { modelo: "Air Zoom Pegasus 38", precio: 130 },
    { modelo: "Blazer Mid '77", precio: 100 },
]
const eleccionAdidas = [
    { modelo: "Ultraboost", precio: 180 },
    { modelo: "Superstar", precio: 85 },
    { modelo: "Stan Smith", precio: 90 },
    { modelo: "NMD_R1", precio: 150 },
    { modelo: "Samba OG", precio: 70 },
  ];
  
  const eleccionPuma = [
    { modelo: "Suede Classic", precio: 70 },
    { modelo: "RS-X", precio: 90 },
    { modelo: "Cali", precio: 80 },
    { modelo: "Clyde", precio: 75 },
    { modelo: "Future Rider", precio: 85 },
  ];
  
  const eleccionReebok = [
    { modelo: "Classic Leather", precio: 75 },
    { modelo: "Club C 85", precio: 65 },
    { modelo: "Instapump Fury", precio: 160 },
    { modelo: "Nano X1", precio: 130 },
    { modelo: "Zig Kinetica", precio: 100 },
  ];
  
  const eleccionConverse = [
    { modelo: "Chuck Taylor All Star", precio: 55 },
    { modelo: "Chuck 70", precio: 75 },
    { modelo: "One Star", precio: 65 },
    { modelo: "Pro Leather", precio: 70 },
    { modelo: "Jack Purcell", precio: 75 },
  ];
  
let eleccion
let productoAñadido
let volver

//FUNCIONES
function elegirMarca(){
    console.log("Seleccione una marca")
    marcas.forEach((marca, index) => console.log(index + 1, marca))
    eleccion = prompt("Seleccione una marca")
    eleccion = eleccion.trim().toLowerCase()

    switch (eleccion) {
        case "nike":
            marcaElegida = eleccionNike
            break
        case "adidas":
            marcaElegida = eleccionAdidas
            break
        case "puma":
            marcaElegida = eleccionPuma
            break
        case "reebok":
            marcaElegida = eleccionReebok
            break
        case "converse":
            marcaElegida = eleccionConverse
            break
        default:
            alert("Ingrese una marca válida, por favor")
            elegirMarca()
            return
    }
    explorarStock()
}

function explorarStock(){
    console.log("Estos son nuestros modelos", eleccion, "en stock:")
    marcaElegida.forEach(producto => {
        console.log(producto.modelo, producto.precio)
    })
    decidirCarrito()
}

function decidirCarrito() {
    volver = prompt("¿Le gustaría agregar al carrito? (Si/No)").trim().toLowerCase();
    if (volver === "si") {
        console.log("¡Genial! Let's go shopping😎")
        anadirCarrito()
    } else if (volver === "no") {
        console.log("Volvamos al inicio entonces😢")
        elegirMarca()
    } else {
        alert("De una respuesta de si o no")
        decidirCarrito()
    }
}

function mostrarCarrito() {
    console.log("Estamos en tu carrito!😀🛒")
    let total = 0;
    carrito.forEach(producto => {
        console.log(producto.modelo, producto.precio);
        total += producto.precio;
    });
    console.log("Total a pagar:", total);
}

function seguirCarrito(){
    mostrarCarrito();
    volver = prompt("¿Agregamos algo más? (Si/No)").trim().toLowerCase()
    if (volver == "no") {
        eliminarProducto()
        console.log("Dirigiendote al menu de inicio")
        elegirMarca()
    } else if (volver == "si") {
        anadirCarrito()
    } else {
        alert("De una respuesta de si o no")
        seguirCarrito()
    }
}

function anadirCarrito() {
    mostrarCarrito()
    if (carrito.length === 0) {
        console.log("El carrito está vacío.")
    } 
    productoAñadido = prompt("¿Qué te gustaría agregar?")

    let productoEncontrado = false;

    for (let i = 0; i < marcaElegida.length; i++) {
        if (productoAñadido.trim().toLowerCase() === marcaElegida[i].modelo.toLowerCase()) {
            carrito.push(marcaElegida[i])
            console.log(marcaElegida[i].modelo, "añadido con éxito! El costo es de", marcaElegida[i].precio)
            productoEncontrado = true
            break
        }
    }

    if (!productoEncontrado) {
        console.log("Producto no encontrado. Asegúrate de escribir correctamente el nombre del modelo y de que hayas seleccionado la marca correcta.");
        seguirCarrito()
    }

    seguirCarrito()
}

function eliminarProducto() {
    let respuesta = prompt("¿Te gustaría eliminar algún producto del carrito? (Si/No)").trim().toLowerCase()
    if (respuesta === "si") {
        let productoAEliminar = prompt("Escribe el nombre del modelo que deseas eliminar:").trim().toLowerCase()
        let producto = carrito.find(p => p.modelo.toLowerCase() === productoAEliminar)
        if (producto) {
            carrito = carrito.filter(p => p.modelo.toLowerCase() !== productoAEliminar)
            console.log(producto.modelo, "eliminado del carrito.")
        } else {
            console.log("Producto no encontrado en el carrito.")
        }
    } else if (respuesta === "no") {
        console.log("No se eliminó ningún producto del carrito.")
    } else {
        console.log("Respuesta no válida. Por favor, responde con 'si' o 'no'.")
        eliminarProducto()
    }
}


//CODIGO👟🙋‍♂️
console.log("Bienvenido a Footloose Co.")
elegirMarca()
