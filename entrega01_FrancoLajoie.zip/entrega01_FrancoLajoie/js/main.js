//VARIABLES
const marcas = ["Nike", "Adidas", "Puma", "Reebok", "Converse"]
let carrito = []
let marcaElegida = []

const eleccionNike = [
    { modelo: "Air Max 90", precio: 120 },
    { modelo: "Air Force 1", precio: 110 },
    { modelo: "Air Zoom Pegasus 38", precio: 130 },
    { modelo: "Blazer Mid '77", precio: 100 },
]
const eleccionAdidas = [
    { modelo: "Ultraboost", precio: 180 },
    { modelo: "Superstar", precio: 85 },
    { modelo: "Stan Smith", precio: 90 },
    { modelo: "NMD_R1", precio: 150 },
    { modelo: "Samba OG", precio: 70 },
  ];
  
  const eleccionPuma = [
    { modelo: "Suede Classic", precio: 70 },
    { modelo: "RS-X", precio: 90 },
    { modelo: "Cali", precio: 80 },
    { modelo: "Clyde", precio: 75 },
    { modelo: "Future Rider", precio: 85 },
  ];
  
  const eleccionReebok = [
    { modelo: "Classic Leather", precio: 75 },
    { modelo: "Club C 85", precio: 65 },
    { modelo: "Instapump Fury", precio: 160 },
    { modelo: "Nano X1", precio: 130 },
    { modelo: "Zig Kinetica", precio: 100 },
  ];
  
  const eleccionConverse = [
    { modelo: "Chuck Taylor All Star", precio: 55 },
    { modelo: "Chuck 70", precio: 75 },
    { modelo: "One Star", precio: 65 },
    { modelo: "Pro Leather", precio: 70 },
    { modelo: "Jack Purcell", precio: 75 },
  ];
  
let eleccion
let productoAñadido
let volver

//FUNCIONES
function elegirMarca(){
    console.log("Seleccione una marca")
    for (let i = 0; i < marcas.length; i++) {
        console.log(marcas[i])
    }
    eleccion = prompt("Seleccione una marca")
    eleccion = eleccion.trim().toLowerCase()
    explorarStock()
}

function explorarStock(){
    switch(eleccion){
        case "nike":
            marcaElegida = eleccionNike
            console.log("Estos son nuestros modelos Nike en stock.")
            for (let i = 0; i < eleccionNike.length; i++) {
                console.log(eleccionNike[i].modelo)
            }
            break
        case "adidas":
            marcaElegida = eleccionAdidas
            console.log("Estos son nuestros modelos Adidas en stock.")
            for (let i = 0; i < eleccionAdidas.length; i++) {
                console.log(eleccionAdidas[i].modelo)
            }
            break
        case "puma":
            marcaElegida = eleccionPuma
            console.log("Estos son nuestros modelos Puma en stock.")
            for (let i = 0; i < eleccionPuma.length; i++) {
                console.log(eleccionPuma[i].modelo)
            }
            break
        case "reebok":
            marcaElegida = eleccionReebok
            console.log("Estos son nuestros modelos Reebok en stock.")
            for (let i = 0; i < eleccionReebok.length; i++) {
                console.log(eleccionReebok[i].modelo)
            }
            break
        case "converse":
            marcaElegida = eleccionConverse
            console.log("Estos son nuestros modelos Converse en stock.")
            for (let i = 0; i < eleccionConverse.length; i++) {
                console.log(eleccionConverse[i].modelo)
            }
            break
        default:
            alert("Ingrese una marca valida, por favor")
            elegirMarca()
    } 
    decidirCarrito()
}

function decidirCarrito() {
    volver = prompt("¿Le gustaría agregar al carrito? (Si/No)").trim().toLowerCase();
    if (volver === "si") {
        console.log("¡Genial! Let's go shopping😎")
        anadirCarrito()
    } else if (volver === "no") {
        console.log("Volvamos al inicio entonces😢")
        elegirMarca()
    } else {
        alert("De una respuesta de si o no")
        decidirCarrito()
    }
}

function seguirCarrito(){
    volver = prompt("¿Agregamos algo más? (Si/No)")
    if (volver == "no") {
        console.log("Dirigiendote al menu de inicio")
        elegirMarca()
    } else if (volver == "si") {
        anadirCarrito()
    } else {
        alert("De una respuesta de si o no")
        seguirCarrito()
    }
}

function anadirCarrito() {
    console.log("Estamos en tu carrito!😀🛒")
    console.log("Hasta ahora tienes:")
    
    if (carrito.length === 0) {
        console.log("El carrito está vacío.")
    } else {
        for (let i = 0; i < carrito.length; i++) {
            console.log(carrito[i].modelo, carrito[i].precio)
        }
    }

    productoAñadido = prompt("¿Qué te gustaría agregar?")
    
    let productoEncontrado = false;

    for (let i = 0; i < marcaElegida.length; i++) {
        if (productoAñadido.trim().toLowerCase() === marcaElegida[i].modelo.toLowerCase()) {
            carrito.push(marcaElegida[i])
            console.log(marcaElegida[i].modelo, "añadido con éxito! El costo es de", marcaElegida[i].precio)
            productoEncontrado = true
            break
        }
    }

    if (!productoEncontrado) {
        console.log("Producto no encontrado. Asegúrate de escribir correctamente el nombre del modelo y de que hayas seleccionado la marca correcta.");
        seguirCarrito()
    }

    seguirCarrito()
}


//CODIGO
console.log("Bienvenido a Footloose Co.👟🙋‍♂️")
elegirMarca()
