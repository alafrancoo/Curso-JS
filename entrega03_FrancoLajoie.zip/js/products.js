const productos = [
    {id: 1, marca: "adidas", modelo: "Campus 00s", precio: 110, imagen: "../assets/img/adidas/campus.png"},
    {id: 2, marca: "adidas", modelo: "Forum Low", precio: 100, imagen: "../assets/img/adidas/forumlow.jpg"},
    {id: 3, marca: "adidas", modelo: "Gazelle Bold", precio: 120, imagen: "../assets/img/adidas/gazellebold.jpg"},
    {id: 4, marca: "adidas", modelo: "Samba OG", precio: 100, imagen: "../assets/img/adidas/sambaog.png"},
    {id: 5, marca: "adidas", modelo: "Handball Spezial", precio: 110, imagen: "../assets/img/adidas/handballspezial.jpg"},
    {id: 6, marca: "nike", modelo: "Blazer Mid ´77", precio: 90, imagen: "../assets/img/nike/blazer77.jpg"},
    {id: 7, marca: "puma", modelo: "Suede XL", precio: 110, imagen: "../assets/img/puma/suedexl.jpg"},
    {id: 8, marca: "vans", modelo: "Knu Skool", precio: 75, imagen: "../assets/img/vans/knuskool.jpg"}
    // {id: 9, marca: , modelo: , precio: , imagen: }
]